#ifndef __HEADER__
// Function defined in calculator.c
int calculator(char op, int num1, int num2);

// Function defined in print_lib.c
void reset ();
void yellow();
void red ();
#endif