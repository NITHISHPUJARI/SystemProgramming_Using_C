#include <stdio.h>

int main()
{
    int x = 1;
    printf("%d\t%d\t%d\r\n", x , ++x, x++);
    return 0;
}
