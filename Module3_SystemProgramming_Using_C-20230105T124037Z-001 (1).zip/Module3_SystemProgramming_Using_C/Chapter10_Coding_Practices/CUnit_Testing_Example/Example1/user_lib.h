#ifndef USER_LIB_H
#define USER_LIB_H

int MySum(int a1, int b1);
int MyDiff(int a2, int b2);
int MyCompare(int number1, int number2);

#endif // #ifndef USER_LIB_H