#include <stdio.h>
#include <stdlib.h>

int maxi(int i, int j)
{
    return i>j?i:j;
	//return i;
}