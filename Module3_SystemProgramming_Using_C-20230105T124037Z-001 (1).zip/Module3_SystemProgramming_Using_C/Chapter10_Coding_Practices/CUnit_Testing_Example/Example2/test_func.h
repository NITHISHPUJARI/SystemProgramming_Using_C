#ifndef TEST_FUNC_H
#define TEST_FUNC_H

void AddTests(void);

#endif // #ifndef TEST_FUNC_H