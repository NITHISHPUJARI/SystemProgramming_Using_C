#ifndef FUNC_H
#define FUNC_H

int maxi(int i, int j);

#endif // #ifndef FUNC_H