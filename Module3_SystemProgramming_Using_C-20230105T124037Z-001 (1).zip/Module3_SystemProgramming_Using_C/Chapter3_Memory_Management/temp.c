
typedef struct {            typedef struct {
    int quot, rem;               long int quot, rem;
} div_t;                    } ldiv_t;



   
