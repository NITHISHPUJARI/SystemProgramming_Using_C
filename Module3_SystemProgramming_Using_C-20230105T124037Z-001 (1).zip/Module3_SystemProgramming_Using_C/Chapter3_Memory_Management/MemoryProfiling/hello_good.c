// Compile with compiler:   $ gcc -Wall -g hello_good.c -o hello_good
// Test with  valgrind:     $ valgrind --tool=memcheck  ./hello_good
//
#include <stdlib.h>
int main()
{
  return 0;
} 