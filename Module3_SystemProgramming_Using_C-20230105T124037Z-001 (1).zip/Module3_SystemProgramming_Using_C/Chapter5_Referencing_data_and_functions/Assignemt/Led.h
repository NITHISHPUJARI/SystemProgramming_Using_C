///
/// \file 				Led.h


#ifndef LED_H
#define LED_H

void Led_Init();
void Led_Idle();
void Led_On();
void Led_Off();

#endif // #ifndef LED_H